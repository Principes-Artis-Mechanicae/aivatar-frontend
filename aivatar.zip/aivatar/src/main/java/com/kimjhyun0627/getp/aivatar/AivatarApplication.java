package com.kimjhyun0627.getp.aivatar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AivatarApplication {

	public static void main(String[] args) {
		SpringApplication.run(AivatarApplication.class, args);
	}

}
