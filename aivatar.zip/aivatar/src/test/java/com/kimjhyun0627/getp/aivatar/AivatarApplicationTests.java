package com.kimjhyun0627.getp.aivatar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AivatarApplicationTests {

	@Test
	void contextLoads() {
	}

}
